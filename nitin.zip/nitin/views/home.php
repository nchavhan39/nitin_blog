<?php
echo SITE_NAME."<br>";
echo $data['content1']."<br>";
echo $data['content2'];
echo $data['content3'];