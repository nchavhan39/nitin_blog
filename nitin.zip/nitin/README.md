# simplemvc
Tiny MVC framework

This piece of code demonstrates simple concepts of a framework 

How controllers , Models, views and libraries are used.

Things added so far

1) Default Home controller with Default View<br>
2) If no controller presents then error controller to handle error view.<br>
3) Use of External library, added db handler which connects mysql via PDO.<br>
4) use of models, added emp model to fetch data from database.<br>
5) Partial views ie one view can be included in many places as required.
