<div>
this view can be included in another file