<?php 
echo "<pre>";
print_r($data['emp_data']);
echo "</pre>";