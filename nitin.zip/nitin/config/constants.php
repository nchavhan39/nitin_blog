<?php
/**
 * Constants file
 */
define('DB_HOST','localhost');
define('DB_USER','root');
define('DB_PASSWORD','');
define('DB_NAME','nitinBlog');
define("SITE_NAME","MY SITE (this is from constants file)");